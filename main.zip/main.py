from kivy.app import App
# from kivy.properties import StringProperty, BooleanProperty
from kivy.uix.screenmanager import ScreenManager, Screen
import pymongo
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout

my_client = pymongo.MongoClient("mongodb://localhost:27017")
mydb = my_client["mydatabase"]
mycol = mydb["customers"]

Window.clearcolor = (1, 1, 1, 1)


class Login(Screen):
    pass


class Create(Screen):
    pass


class Home(Screen):
    pass


class Bookride(Screen):
    pass


class Notification(Screen):
    pass


class Search(Screen):
    pass


class Histroy(Screen):
    pass


class Termsandconditions(Screen):
    pass


class Payment(Screen):
    pass


class Float(FloatLayout):
    pass


class Screenm(ScreenManager):
    pass


class DemoApp(App):
    pass


if __name__ == '__main__':
    DemoApp().run()
